package com.example.tiktokcounter

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val bg = 0xFF0E1220.toInt()
    private lateinit var prefs: SharedPreferences
    private lateinit var countView: TextView
    private lateinit var statusView: TextView
    private lateinit var enableBtn: TextView
    private var shown = -1

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") refresh(true)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(t: String, fill: Int?, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (fill != null) 0xFF10131F.toInt() else 0xFFFFFFFF.toInt())
        setPadding(dp(20), dp(16), dp(20), dp(16))
        val shape = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            if (fill != null) {
                setColor(fill)
            } else {
                setColor(0x1AFFFFFF)
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, null)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.addGap(v: View, top: Int = 14) {
        addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("counter", MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            ImageView(this).apply { setImageResource(R.drawable.ic_logo) },
            LinearLayout.LayoutParams(dp(64), dp(64))
        )
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(label("Hitung Scroll", 24f, 0xFFFFFFFF.toInt(), true))
        titles.addView(label("TikTok · YouTube Shorts · Reels", 13f, 0xFF9AA3C0.toInt()))
        header.addView(titles)
        box.addView(header)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF3A2C8F.toInt(), 0xFFB5367A.toInt())
            ).apply { cornerRadius = dp(30).toFloat() }
        }
        card.addView(label("Sudah di-scroll", 14f, 0xCCFFFFFF.toInt()))
        countView = label("0", 84f, 0xFFFFFFFF.toInt(), true)
        card.addView(countView)
        statusView = label("", 14f, 0xFFFFFFFF.toInt(), true)
        card.addView(statusView)
        box.addGap(card, 26)

        enableBtn = button("Aktifkan layanan", 0xFFFFD23F.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        box.addGap(enableBtn, 22)

        box.addGap(button("Reset hitungan", null) {
            prefs.edit().putInt("count", 0).apply()
        })

        val sw = Switch(this).apply {
            text = "Hitung semua scroll di YouTube dan Instagram (tanpa deteksi Shorts/Reels)"
            textSize = 14f
            setTextColor(0xFFC9CFE6.toInt())
            isChecked = prefs.getBoolean("all", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("all", v).apply() }
        }
        box.addGap(sw, 22)

        box.addGap(
            label(
                "1. Ketuk Aktifkan layanan, pilih Hitung Scroll Video, lalu nyalakan.\n" +
                    "2. Buka TikTok, YouTube Shorts, atau Instagram Reels dan mulai scroll.\n" +
                    "3. Angkanya tampil di kiri atas layar dan naik tiap pindah video.",
                13f, 0xFF8791B0.toInt()
            ), 22
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(box)
        })
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refresh(false)
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    private fun isServiceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/")
    }

    private fun refresh(animate: Boolean) {
        val c = prefs.getInt("count", 0)
        countView.text = c.toString()
        if (animate && shown >= 0 && c > shown) pulse()
        shown = c
        val on = isServiceOn()
        statusView.text = if (on) "● Layanan aktif" else "● Belum aktif"
        statusView.setTextColor(if (on) 0xFF7CFFB2.toInt() else 0xFFFFC46B.toInt())
        enableBtn.text = if (on) "Pengaturan Aksesibilitas" else "Aktifkan layanan"
    }

    private fun pulse() {
        countView.animate().cancel()
        countView.animate().scaleX(1.25f).scaleY(1.25f).setDuration(100).withEndAction {
            countView.animate().scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }
}
