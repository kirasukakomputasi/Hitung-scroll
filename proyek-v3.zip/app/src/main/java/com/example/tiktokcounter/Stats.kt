package com.example.tiktokcounter

import android.content.Context
import java.time.LocalDate
import java.time.LocalDateTime

/** Riwayat per jam: jumlah scroll ("c") dan detik berada di aplikasi ("s"). */
object Stats {
    private fun sp(c: Context) = c.getSharedPreferences("stats", Context.MODE_PRIVATE)

    fun addCount(c: Context) {
        val now = LocalDateTime.now()
        val k = "c_${now.toLocalDate()}_${now.hour}"
        val p = sp(c)
        p.edit().putInt(k, p.getInt(k, 0) + 1).apply()
    }

    fun addSeconds(c: Context, s: Int) {
        if (s <= 0) return
        val now = LocalDateTime.now()
        val k = "s_${now.toLocalDate()}_${now.hour}"
        val p = sp(c)
        p.edit().putInt(k, p.getInt(k, 0) + s).apply()
    }

    fun hourly(c: Context, prefix: String, date: LocalDate): IntArray {
        val p = sp(c)
        return IntArray(24) { h -> p.getInt("${prefix}_${date}_$h", 0) }
    }

    fun dayTotal(c: Context, prefix: String, date: LocalDate): Int = hourly(c, prefix, date).sum()

    fun clear(c: Context) {
        sp(c).edit().clear().apply()
    }
}
