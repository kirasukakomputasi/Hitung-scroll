package com.example.tiktokcounter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.time.LocalDate

class MainActivity : Activity() {

    private val bg = 0xFF0E1220.toInt()
    private lateinit var prefs: SharedPreferences
    private lateinit var countView: TextView
    private lateinit var statusView: TextView
    private lateinit var todayView: TextView
    private lateinit var enableBtn: TextView
    private lateinit var chart: BarChartView
    private lateinit var chartTitle: TextView
    private lateinit var summary: TextView
    private val periodChips = ArrayList<TextView>()
    private val metricChips = ArrayList<TextView>()
    private var period = 0   // 0 harian, 1 mingguan, 2 bulanan
    private var metric = 0   // 0 jumlah scroll, 1 waktu
    private var shown = -1

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") refresh(true)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(t: String, fill: Int?, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (fill != null) 0xFF10131F.toInt() else 0xFFFFFFFF.toInt())
        setPadding(dp(20), dp(16), dp(20), dp(16))
        val shape = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            if (fill != null) {
                setColor(fill)
            } else {
                setColor(0x1AFFFFFF)
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, null)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun chip(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(9), dp(8), dp(9))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.setTextColor(if (on) 0xFF10131F.toInt() else 0xFFC9CFE6.toInt())
        c.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(if (on) 0xFFFFD23F.toInt() else 0x1AFFFFFF)
        }
    }

    private fun chipRow(names: List<String>, store: ArrayList<TextView>, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEachIndexed { i, n ->
            val c = chip(n) { onPick(i) }
            store.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        return row
    }

    private fun LinearLayout.addGap(v: View, top: Int = 14) {
        addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("counter", MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            ImageView(this).apply { setImageResource(R.drawable.ic_logo) },
            LinearLayout.LayoutParams(dp(64), dp(64))
        )
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(label("Hitung Scroll", 24f, 0xFFFFFFFF.toInt(), true))
        titles.addView(label("TikTok · YouTube Shorts · Reels", 13f, 0xFF9AA3C0.toInt()))
        header.addView(titles)
        box.addView(header)

        // Kartu hitungan
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF3A2C8F.toInt(), 0xFFB5367A.toInt())
            ).apply { cornerRadius = dp(30).toFloat() }
        }
        card.addView(label("Sudah di-scroll", 14f, 0xCCFFFFFF.toInt()))
        countView = label("0", 84f, 0xFFFFFFFF.toInt(), true)
        card.addView(countView)
        todayView = label("", 14f, 0xFFFFFFFF.toInt())
        card.addView(todayView)
        statusView = label("", 14f, 0xFFFFFFFF.toInt(), true)
        card.addGap(statusView, 8)
        box.addGap(card, 26)

        // Laporan
        val report = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                setColor(0xFF171C30.toInt())
            }
        }
        report.addView(label("Laporan", 18f, 0xFFFFFFFF.toInt(), true))
        report.addGap(chipRow(listOf("Harian", "Mingguan", "Bulanan"), periodChips) {
            period = it
            renderReport()
        }, 12)
        report.addGap(chipRow(listOf("Jumlah scroll", "Waktu"), metricChips) {
            metric = it
            renderReport()
        }, 8)
        chartTitle = label("", 13f, 0xFF9AA3C0.toInt())
        report.addGap(chartTitle, 14)
        chart = BarChartView(this)
        report.addView(chart, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(170)
        ).apply { topMargin = dp(6) })
        summary = label("", 14f, 0xFFC9CFE6.toInt())
        report.addGap(summary, 10)
        box.addGap(report, 18)

        enableBtn = button("Aktifkan layanan", 0xFFFFD23F.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        box.addGap(enableBtn, 22)

        box.addGap(button("Reset hitungan", null) {
            prefs.edit().putInt("count", 0).apply()
        })

        val sw = Switch(this).apply {
            text = "Hitung semua scroll di YouTube dan Instagram (tanpa deteksi Shorts/Reels)"
            textSize = 14f
            setTextColor(0xFFC9CFE6.toInt())
            isChecked = prefs.getBoolean("all", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("all", v).apply() }
        }
        box.addGap(sw, 22)

        box.addGap(button("Hapus riwayat laporan", null) {
            AlertDialog.Builder(this@MainActivity)
                .setMessage("Hapus semua riwayat laporan harian, mingguan, dan bulanan?")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus") { _, _ ->
                    Stats.clear(this@MainActivity)
                    refresh(false)
                    renderReport()
                }
                .show()
        }, 14)

        box.addGap(
            label(
                "1. Ketuk Aktifkan layanan, pilih Hitung Scroll Video, lalu nyalakan.\n" +
                    "2. Buka TikTok, YouTube Shorts, atau Instagram Reels dan mulai scroll.\n" +
                    "3. Kotak di kiri atas layar menampilkan hitungan dan timer. Waktu dihitung selama Anda berada di aplikasi video dan layar menyala.",
                13f, 0xFF8791B0.toInt()
            ), 22
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(box)
        })
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refresh(false)
        renderReport()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    private fun isServiceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/")
    }

    private fun dur(s: Int): String = when {
        s < 60 -> "$s detik"
        s < 3600 -> "${s / 60} menit"
        else -> "${s / 3600} jam ${(s % 3600) / 60} menit"
    }

    private fun dayName(d: LocalDate): String =
        arrayOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")[d.dayOfWeek.value - 1]

    private fun refresh(animate: Boolean) {
        val c = prefs.getInt("count", 0)
        countView.text = c.toString()
        if (animate && shown >= 0 && c > shown) pulse()
        shown = c
        val on = isServiceOn()
        statusView.text = if (on) "● Layanan aktif" else "● Belum aktif"
        statusView.setTextColor(if (on) 0xFF7CFFB2.toInt() else 0xFFFFC46B.toInt())
        enableBtn.text = if (on) "Pengaturan Aksesibilitas" else "Aktifkan layanan"
        val today = LocalDate.now()
        todayView.text = "Hari ini: ${Stats.dayTotal(this, "c", today)} scroll · " +
            dur(Stats.dayTotal(this, "s", today))
    }

    private fun renderReport() {
        periodChips.forEachIndexed { i, c -> styleChip(c, i == period) }
        metricChips.forEachIndexed { i, c -> styleChip(c, i == metric) }
        val today = LocalDate.now()
        val prefix = if (metric == 0) "c" else "s"
        val vals = ArrayList<Float>()
        val labs = ArrayList<String>()
        fun v(x: Int): Float = if (metric == 0) x.toFloat() else x / 60f

        when (period) {
            0 -> {
                val arr = Stats.hourly(this, prefix, today)
                for (h in 0..23) {
                    vals.add(v(arr[h]))
                    labs.add(if (h % 6 == 0) h.toString() else "")
                }
            }
            1 -> for (i in 6 downTo 0) {
                val d = today.minusDays(i.toLong())
                vals.add(v(Stats.dayTotal(this, prefix, d)))
                labs.add(dayName(d))
            }
            else -> for (i in 29 downTo 0) {
                val d = today.minusDays(i.toLong())
                vals.add(v(Stats.dayTotal(this, prefix, d)))
                labs.add(if (i % 5 == 0) d.dayOfMonth.toString() else "")
            }
        }
        val what = if (metric == 0) "jumlah scroll" else "menit di aplikasi"
        chartTitle.text = when (period) {
            0 -> "Hari ini, per jam ($what)"
            1 -> "7 hari terakhir ($what)"
            else -> "30 hari terakhir ($what)"
        }
        chart.setData(vals, labs)

        val n = when (period) { 0 -> 1; 1 -> 7; else -> 30 }
        var totalC = 0
        var totalS = 0
        for (i in 0 until n) {
            val d = today.minusDays(i.toLong())
            totalC += Stats.dayTotal(this, "c", d)
            totalS += Stats.dayTotal(this, "s", d)
        }
        summary.text = if (period == 0) {
            val y = today.minusDays(1)
            "Hari ini: $totalC scroll · ${dur(totalS)}\n" +
                "Kemarin: ${Stats.dayTotal(this, "c", y)} scroll · ${dur(Stats.dayTotal(this, "s", y))}"
        } else {
            "Total: $totalC scroll · ${dur(totalS)}\n" +
                "Rata-rata per hari: ${totalC / n} scroll · ${dur(totalS / n)}"
        }
    }

    private fun pulse() {
        countView.animate().cancel()
        countView.animate().scaleX(1.25f).scaleY(1.25f).setDuration(100).withEndAction {
            countView.animate().scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }
}
