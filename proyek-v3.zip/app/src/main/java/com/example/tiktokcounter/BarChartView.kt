package com.example.tiktokcounter

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator

class BarChartView(ctx: Context) : View(ctx) {
    private var values: List<Float> = emptyList()
    private var labels: List<String> = emptyList()
    private var progress = 1f
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8791B0.toInt()
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setData(v: List<Float>, l: List<String>) {
        values = v
        labels = l
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 550
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        txt.textSize = dp(11f)
        val labelH = dp(20f)
        val top0 = dp(4f)
        val chartH = height - labelH - top0
        val maxV = maxOf(values.maxOrNull() ?: 0f, 1f)
        val slot = width.toFloat() / n
        val bw = slot * 0.62f
        val radius = minOf(bw / 2f, dp(6f))
        for (i in 0 until n) {
            val minH = if (values[i] > 0f) dp(3f) else dp(1.5f)
            val h = maxOf(values[i] / maxV * chartH * progress, minH)
            val left = i * slot + (slot - bw) / 2f
            rect.set(left, top0 + chartH - h, left + bw, top0 + chartH)
            bar.color = when {
                i == n - 1 -> 0xFFFFD23F.toInt()
                values[i] > 0f -> 0xFFB58CFF.toInt()
                else -> 0x22FFFFFF
            }
            canvas.drawRoundRect(rect, radius, radius, bar)
            val l = labels.getOrElse(i) { "" }
            if (l.isNotEmpty()) canvas.drawText(l, left + bw / 2f, height - dp(4f), txt)
        }
    }
}
