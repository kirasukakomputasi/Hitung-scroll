package com.example.tiktokcounter

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class CounterService : AccessibilityService() {

    // TikTok global dan versi Asia (termasuk Indonesia): semua scroll dihitung
    private val always = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    // YouTube dan Instagram: hanya dihitung kalau layar Shorts/Reels terdeteksi
    private val shortForm = setOf("com.google.android.youtube", "com.instagram.android")
    private val supported = always + shortForm
    private var lastPkg = ""

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences

    private var overlay: View? = null
    private var numView: TextView? = null
    private var subView: TextView? = null
    private var timerView: TextView? = null
    private var plusView: TextView? = null
    private var hintView: TextView? = null
    private var shown = -1
    private var visited = 0
    private var sessionSec = 0
    private var pendingSec = 0

    private val hideHint = Runnable { hintView?.visibility = View.GONE }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") render(true)
    }

    // Satu geseran memicu banyak event; hitung 1 kali setelah event berhenti 500 ms.
    private val commit = Runnable {
        val countAll = prefs.getBoolean("all", false)
        if (lastPkg in always || countAll || inShortFeed()) {
            prefs.edit().putInt("count", prefs.getInt("count", 0) + 1).apply()
            Stats.addCount(this)
        } else {
            showHint("Diabaikan: bukan layar Shorts/Reels")
        }
    }

    // Timer: berjalan tiap detik selama kotak tampil dan layar menyala.
    private val tick = object : Runnable {
        override fun run() {
            if (overlay == null) return
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) {
                hide()
                return
            }
            sessionSec++
            pendingSec++
            timerView?.text = "⏱ " + fmt(sessionSec)
            if (pendingSec >= 10) flushSeconds()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fmt(s: Int): String {
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%02d:%02d".format(m, ss)
    }

    private fun flushSeconds() {
        if (pendingSec > 0) Stats.addSeconds(this, pendingSec)
        pendingSec = 0
    }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("counter", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (pkg in supported) show()
                else if (pkg != "com.android.systemui" && pkg != packageName) hide()
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (pkg in supported) {
                    lastPkg = pkg
                    show()
                    handler.removeCallbacks(commit)
                    handler.postDelayed(commit, 500)
                }
            }
        }
    }

    private fun inShortFeed(): Boolean {
        val root = rootInActiveWindow ?: return false
        visited = 0
        return scan(root, 0)
    }

    private fun scan(n: AccessibilityNodeInfo, depth: Int): Boolean {
        if (depth > 30 || visited > 4000) return false
        visited++
        val id = n.viewIdResourceName?.lowercase()
        if (id != null && (id.contains("reel") || id.contains("shorts") || id.contains("clips"))) return true
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (scan(c, depth + 1)) return true
        }
        return false
    }

    private fun show() {
        if (overlay != null) return
        val root = FrameLayout(this).apply {
            clipChildren = false
            setPadding(0, dp(30), 0, 0)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(20), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xF01B1F4B.toInt(), 0xF04A1D63.toInt())
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), 0x40FFFFFF)
            }
        }
        val num = TextView(this).apply {
            text = "0"
            textSize = 36f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFD23F.toInt())
            gravity = Gravity.CENTER
            minWidth = dp(44)
            setPadding(0, 0, dp(14), 0)
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this).apply {
            text = "video di-scroll"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
        }
        val sub = TextView(this).apply {
            textSize = 12f
            setTextColor(0xB3FFFFFF.toInt())
        }
        val timer = TextView(this).apply {
            text = "⏱ 00:00"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF8EE3FF.toInt())
        }
        val hint = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFFFB454.toInt())
            visibility = View.GONE
        }
        col.addView(label)
        col.addView(sub)
        col.addView(timer)
        col.addView(hint)
        card.addView(num)
        card.addView(col)

        val plus = TextView(this).apply {
            text = "+1"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF4ADE80.toInt())
            alpha = 0f
        }
        root.addView(card)
        root.addView(plus, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(20)
            topMargin = dp(36)
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(70)
        }
        wm.addView(root, lp)
        overlay = root
        numView = num
        subView = sub
        timerView = timer
        plusView = plus
        hintView = hint

        root.alpha = 0f
        root.translationX = -dp(40).toFloat()
        root.animate().alpha(1f).translationX(0f).setDuration(260).start()
        render(false)

        sessionSec = 0
        pendingSec = 0
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 1000)
    }

    private fun hide() {
        handler.removeCallbacks(tick)
        flushSeconds()
        try {
            overlay?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        overlay = null
        numView = null
        subView = null
        timerView = null
        plusView = null
        hintView = null
    }

    private fun render(animate: Boolean) {
        val c = prefs.getInt("count", 0)
        val old = shown
        shown = c
        numView?.text = c.toString()
        subView?.text = "Video ke-${c + 1}"
        if (animate && old >= 0 && c > old) pop()
    }

    private fun pop() {
        val n = numView ?: return
        n.animate().cancel()
        n.animate().scaleX(1.45f).scaleY(1.45f).setDuration(110).withEndAction {
            n.animate().scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
        plusView?.let { p ->
            p.animate().cancel()
            p.alpha = 1f
            p.translationY = 0f
            p.animate().translationY(-dp(32).toFloat()).alpha(0f).setDuration(750).start()
        }
    }

    private fun showHint(msg: String) {
        val h = hintView ?: return
        h.text = msg
        h.visibility = View.VISIBLE
        handler.removeCallbacks(hideHint)
        handler.postDelayed(hideHint, 1800)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(commit)
        handler.removeCallbacks(hideHint)
        hide()
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onDestroy()
    }
}
